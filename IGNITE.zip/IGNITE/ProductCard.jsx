import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Heart, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/context/CartContext';
import { toast } from '@/components/ui/use-toast';

const ProductCard = ({ product }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart(product);
    toast({
      title: 'Added to cart!',
      description: `${product.name} has been added to your cart.`,
      duration: 3000,
    });
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    toast({
      title: isLiked ? 'Removed from wishlist' : 'Added to wishlist!',
      description: isLiked 
        ? `${product.name} removed from your wishlist.`
        : `${product.name} added to your wishlist.`,
      duration: 2000,
    });
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <motion.div
      variants={cardVariants}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative bg-gradient-to-br from-slate-900 to-slate-950 rounded-2xl overflow-hidden border border-amber-500/10 hover:border-amber-500/30 transition-all duration-500"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-orange-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <div className="relative aspect-square overflow-hidden">
        <motion.img
          src={product.image}
          alt={`${product.name} - ${product.description}`}
          className="w-full h-full object-cover"
          animate={{ scale: isHovered ? 1.1 : 1 }}
          transition={{ duration: 0.6 }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent opacity-60" />
        
        <motion.button
          onClick={handleLike}
          className="absolute top-4 right-4 w-10 h-10 bg-slate-950/80 backdrop-blur-sm rounded-full flex items-center justify-center border border-amber-500/20 hover:border-amber-500/50 transition-all duration-300"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Heart
            className={`w-5 h-5 transition-all duration-300 ${
              isLiked ? 'fill-amber-500 text-amber-500' : 'text-gray-400'
            }`}
          />
        </motion.button>

        <div className="absolute top-4 left-4">
          <span className="inline-flex items-center gap-1 bg-amber-500/90 backdrop-blur-sm text-white text-xs font-semibold px-3 py-1.5 rounded-full">
            <Sparkles className="w-3 h-3" />
            {product.category}
          </span>
        </div>
      </div>

      <div className="relative p-6">
        <h3 className="text-xl font-bold text-white mb-2 group-hover:text-amber-400 transition-colors duration-300">
          {product.name}
        </h3>
        
        <p className="text-gray-400 text-sm mb-4 line-clamp-2">
          {product.description}
        </p>

        <div className="flex flex-wrap gap-1.5 mb-4">
          {product.notes.map((note, index) => (
            <span
              key={index}
              className="text-xs bg-slate-800/50 text-amber-400/80 px-2 py-1 rounded-full border border-amber-500/20"
            >
              {note}
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-800">
          <div>
            <p className="text-xs text-gray-500 mb-1">Price</p>
            <p className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
              ₹{product.price}
            </p>
          </div>

          <Button
            onClick={handleAddToCart}
            className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white shadow-lg shadow-amber-500/25"
          >
            <ShoppingCart className="w-4 h-4 mr-2" />
            Add to Cart
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;