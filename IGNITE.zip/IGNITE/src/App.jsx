import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import ProductGrid from '@/components/ProductGrid';
import About from '@/components/About';
import Footer from '@/components/Footer';
import { Toaster } from '@/components/ui/toaster';
import { CartProvider } from '@/context/CartContext';

function App() {
  return (
    <CartProvider>
      <Helmet>
        <title>Fragrance By IGNITE - Luxury Perfumes Collection</title>
        <meta name="description" content="Discover IGNITE's exquisite collection of luxury perfumes. Long-lasting, affordable fragrances crafted in India for the modern gentleman and sophisticated woman." />
      </Helmet>
      <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
        <Header />
        <Hero />
        <ProductGrid />
        <About />
        <Footer />
        <Toaster />
      </div>
    </CartProvider>
  );
}

export default App;