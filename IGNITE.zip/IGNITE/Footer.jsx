import React from 'react';
import { Instagram, Facebook, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const Footer = () => {
  const handleSocialClick = (platform) => {
    toast({
      title: '🚧 This feature isn\'t implemented yet—but don\'t worry! You can request it in your next prompt! 🚀',
      description: `Connect your ${platform} account to enable this feature.`,
      duration: 3000,
    });
  };

  const handleContactClick = () => {
    toast({
      title: '🚧 This feature isn\'t implemented yet—but don\'t worry! You can request it in your next prompt! 🚀',
      description: 'Contact form functionality coming soon.',
      duration: 3000,
    });
  };

  return (
    <footer className="bg-gradient-to-b from-slate-950 to-black border-t border-amber-500/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">I</span>
              </div>
              <div>
                <span className="text-xl font-bold text-white">IGNITE</span>
                <p className="text-xs text-amber-400 -mt-1">Fragrances</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Luxury perfumes crafted with passion, designed for elegance.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => handleSocialClick('Instagram')}
                className="w-9 h-9 bg-slate-800 hover:bg-amber-500/20 border border-amber-500/20 hover:border-amber-500/40 rounded-lg flex items-center justify-center transition-all duration-300"
              >
                <Instagram className="w-4 h-4 text-gray-400 hover:text-amber-400" />
              </button>
              <button
                onClick={() => handleSocialClick('Facebook')}
                className="w-9 h-9 bg-slate-800 hover:bg-amber-500/20 border border-amber-500/20 hover:border-amber-500/40 rounded-lg flex items-center justify-center transition-all duration-300"
              >
                <Facebook className="w-4 h-4 text-gray-400 hover:text-amber-400" />
              </button>
              <button
                onClick={() => handleSocialClick('Twitter')}
                className="w-9 h-9 bg-slate-800 hover:bg-amber-500/20 border border-amber-500/20 hover:border-amber-500/40 rounded-lg flex items-center justify-center transition-all duration-300"
              >
                <Twitter className="w-4 h-4 text-gray-400 hover:text-amber-400" />
              </button>
            </div>
          </div>

          <div>
            <span className="text-white font-semibold mb-4 block">Shop</span>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => {
                    const element = document.getElementById('products');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-gray-400 hover:text-amber-400 transition-colors duration-300 text-sm"
                >
                  All Products
                </button>
              </li>
              <li>
                <button onClick={handleContactClick} className="text-gray-400 hover:text-amber-400 transition-colors duration-300 text-sm">
                  Men's Collection
                </button>
              </li>
              <li>
                <button onClick={handleContactClick} className="text-gray-400 hover:text-amber-400 transition-colors duration-300 text-sm">
                  Women's Collection
                </button>
              </li>
              <li>
                <button onClick={handleContactClick} className="text-gray-400 hover:text-amber-400 transition-colors duration-300 text-sm">
                  Gift Sets
                </button>
              </li>
            </ul>
          </div>

          <div>
            <span className="text-white font-semibold mb-4 block">Company</span>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => {
                    const element = document.getElementById('about');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-gray-400 hover:text-amber-400 transition-colors duration-300 text-sm"
                >
                  About Us
                </button>
              </li>
              <li>
                <button onClick={handleContactClick} className="text-gray-400 hover:text-amber-400 transition-colors duration-300 text-sm">
                  Our Story
                </button>
              </li>
              <li>
                <button onClick={handleContactClick} className="text-gray-400 hover:text-amber-400 transition-colors duration-300 text-sm">
                  Careers
                </button>
              </li>
              <li>
                <button onClick={handleContactClick} className="text-gray-400 hover:text-amber-400 transition-colors duration-300 text-sm">
                  Contact
                </button>
              </li>
            </ul>
          </div>

          <div>
            <span className="text-white font-semibold mb-4 block">Contact Us</span>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-gray-400 text-sm">
                <Mail className="w-4 h-4 mt-0.5 text-amber-400" />
                <span>info@ignitefragrances.com</span>
              </li>
              <li className="flex items-start gap-2 text-gray-400 text-sm">
                <Phone className="w-4 h-4 mt-0.5 text-amber-400" />
                <span>+91 82372 28894</span>
              </li>
              <li className="flex items-start gap-2 text-gray-400 text-sm">
                <MapPin className="w-4 h-4 mt-0.5 text-amber-400" />
                <span>Mumbai, Maharashtra, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">
              © 2026 IGNITE Fragrances. All rights reserved By Adiya Gupta.
            </p>
            <div className="flex gap-6">
              <button onClick={handleContactClick} className="text-gray-500 hover:text-amber-400 text-sm transition-colors duration-300">
                Privacy Policy
              </button>
              <button onClick={handleContactClick} className="text-gray-500 hover:text-amber-400 text-sm transition-colors duration-300">
                Terms of Service
              </button>
              <button onClick={handleContactClick} className="text-gray-500 hover:text-amber-400 text-sm transition-colors duration-300">
                Shipping Policy
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;