import React, { useState } from 'react';
import { motion } from 'framer-motion';
import ProductCard from '@/components/ProductCard';

const ProductGrid = () => {
  const [products] = useState([
    {
      id: 1,
      name: 'Man Red Classic',
      category: 'For Him',
      price: 799,
      image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=500&auto=format',
      description: 'Bold and captivating masculine fragrance',
      notes: ['Bergamot', 'Leather', 'Amber']
    },
    {
      id: 2,
      name: 'Wonder Woman Themyscira',
      category: 'For Her',
      price: 849,
      image: 'https://images.unsplash.com/photo-1588405748880-12d1d2a59db9?w=500&auto=format',
      description: 'Elegant floral with a mysterious touch',
      notes: ['Rose', 'Jasmine', 'Vanilla']
    },
    {
      id: 3,
      name: 'Gental Man Classic',
      category: 'For Him',
      price: 899,
      image: 'https://images.unsplash.com/photo-1587017539504-67cfbddac569?w=500&auto=format',
      description: 'Sophisticated and timeless gentleman\'s choice',
      notes: ['Sandalwood', 'Cedar', 'Musk']
    },
    {
      id: 4,
      name: 'Signature Collection',
      category: 'Unisex',
      price: 999,
      image: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=500&auto=format',
      description: 'Our premium signature blend',
      notes: ['Oud', 'Saffron', 'Patchouli']
    },
    {
      id: 5,
      name: 'Night Edition',
      category: 'For Him',
      price: 949,
      image: 'https://images.unsplash.com/photo-1590156152305-0c5c61d7e0c5?w=500&auto=format',
      description: 'Intense evening fragrance',
      notes: ['Black Pepper', 'Tobacco', 'Vetiver']
    },
    {
      id: 6,
      name: 'Blossom Romance',
      category: 'For Her',
      price: 899,
      image: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?w=500&auto=format',
      description: 'Romantic floral bouquet',
      notes: ['Peony', 'Magnolia', 'White Musk']
    }
  ]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <section id="products" className="py-20 px-4 sm:px-6 lg:px-8 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-amber-950/5 to-transparent" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white to-amber-300 bg-clip-text text-transparent">
            Our Collection
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Discover our exquisite range of long-lasting perfumes, crafted with the finest ingredients
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default ProductGrid;