import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Award, Heart, Clock } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: Sparkles,
      title: 'Premium Quality',
      description: 'Crafted with the finest ingredients sourced globally'
    },
    {
      icon: Clock,
      title: 'Long Lasting',
      description: 'Fragrances that stay with you throughout the day'
    },
    {
      icon: Award,
      title: 'Affordable Luxury',
      description: 'Top quality perfumes at accessible prices'
    },
    {
      icon: Heart,
      title: 'Made in India',
      description: 'Proudly manufactured with Indian craftsmanship'
    }
  ];

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-amber-950/10 via-transparent to-amber-950/10" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-white to-amber-300 bg-clip-text text-transparent">
              About IGNITE
            </h2>
            <p className="text-gray-400 text-lg mb-6 leading-relaxed">
              IGNITE is India's premier luxury perfume brand, dedicated to creating 
              exquisite fragrances that ignite your senses and leave lasting impressions.
            </p>
            <p className="text-gray-400 text-lg leading-relaxed">
              Each fragrance in our collection is meticulously crafted with passion and 
              precision, combining traditional perfumery techniques with modern innovation 
              to deliver scents that are both timeless and contemporary.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="relative aspect-square rounded-2xl overflow-hidden">
              <img
                src="https://horizons-cdn.hostinger.com/70fa44a9-7371-47d8-a535-6d9db49f0521/8c1b3a00133067fca721fdc9d2b55a54.jpg"
                alt="IGNITE Wonder Woman Themyscira perfume with elegant heart decoration"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-gradient-to-br from-slate-900 to-slate-950 border border-amber-500/10 rounded-xl p-6 hover:border-amber-500/30 transition-all duration-300 group"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default About;